
# Multipage Portfolio Website

Responsive multipage site built with HTML5, CSS, and JavaScript.

## Pages
- Home
- About
- Services
- Gallery
- Contact

## Features
- Responsive layout
- Shared header and footer
- JavaScript interactivity (form validation/alert)

## Deployment
1. Push to a GitHub repository.
2. Enable GitHub Pages in repository settings, branch `main`, folder `/`.
3. Or drag-and-drop to Netlify/Vercel for instant deployment.
