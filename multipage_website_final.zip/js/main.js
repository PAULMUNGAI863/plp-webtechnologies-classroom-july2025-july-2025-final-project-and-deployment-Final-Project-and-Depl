
document.addEventListener('DOMContentLoaded', function(){
  const form = document.getElementById('contactForm');
  if(form){
    form.addEventListener('submit', e => {
      e.preventDefault();
      alert('Form submitted!');
    });
  }
});
